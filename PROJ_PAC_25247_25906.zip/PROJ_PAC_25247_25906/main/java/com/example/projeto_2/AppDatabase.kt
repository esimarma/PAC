package com.example.projeto_2

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.projeto_2.AppDatabase.Companion
import com.example.projeto_2.AppDatabase.Companion.DatabaseCallback
import com.example.projeto_2.AppDatabase.Companion.INSTANCE
import com.example.projeto_2.dao.ClubDao
import com.example.projeto_2.dao.GameDao
import com.example.projeto_2.dao.TeamDao
import com.example.projeto_2.dao.TrainingDao
import com.example.projeto_2.dao.UserDao
import com.example.projeto_2.entities.Club
import com.example.projeto_2.entities.ClubModalityCrossRef
import com.example.projeto_2.entities.Game
import com.example.projeto_2.entities.Modality
import com.example.projeto_2.entities.Team
import com.example.projeto_2.entities.Training
import com.example.projeto_2.entities.User
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [User::class, Club::class, Modality::class, ClubModalityCrossRef::class, Game::class, Team::class, Training::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun clubDao(): ClubDao
    abstract fun teamDao(): TeamDao
    abstract fun gameDao(): GameDao
    abstract fun trainingDao(): TrainingDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "app_database"
                )
                    //.addMigrations(MIGRATION_1_2)
                    .addCallback(DatabaseCallback(context))
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(private val context: Context) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        populateDatabase(database.userDao())
                    }
                }
            }

            suspend fun populateDatabase(userDao: UserDao) {
                // Adiciona dados pré-definidos para User
                val users = listOf(
                    User(0, "user1", "1234", "Marisa",1),
                    User(0, "user2", "1234", "Nuno", 2),
                    User(0, "user3", "1234", "Sofia",3)
                )
                userDao.insertAll(users)
            }
        }
    }
}
