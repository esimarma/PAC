package com.example.projeto_2

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.projeto_2.screens.AboutScreenComp
import com.example.projeto_2.screens.GamesResultsScreenComp
import com.example.projeto_2.screens.LoginScreenComp
import com.example.projeto_2.screens.SearchClubScreenComp
import com.example.projeto_2.screens.TeamsScreenComp
import com.example.projeto_2.screens.TrainingScreenComp
import com.example.projeto_2.ui.theme.Projeto_2Theme
import com.example.projeto_2.viewModel.DataViewModel
import kotlinx.serialization.Serializable

class MainActivity : ComponentActivity() {
    private val dataViewModel: DataViewModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Projeto_2Theme {
                MyApp(dataViewModel/*, clubViewModel*/)
            }
        }
    }
}

@Composable
fun MyApp(dataViewModel: DataViewModel/*, clubViewModel: ClubViewModel*/) {
    val navController = rememberNavController()
    NavHost(
        navController = navController,
        startDestination = LoginScreen
    ){
        composable<LoginScreen> {
            LoginScreenComp(navController = navController,dataViewModel)
        }
        composable<SearchClubScreen> {
            val args = it.toRoute<SearchClubScreen>()
            SearchClubScreenComp(navController = navController, dataViewModel/*, args.teamId*/)
        }
        composable<TeamsScreen> {
            val args = it.toRoute<TeamsScreen>()
            TeamsScreenComp(dataViewModel, navController = navController, args.teamId, args.clubId, args.clubName,args.clubPhoneNum, args.clubEmail, args.clubAddress,args.user)
        }
        composable<GamesResultsScreen> {
            val args = it.toRoute<GamesResultsScreen>()
            GamesResultsScreenComp(dataViewModel, navController = navController, args.teamId, args.clubId, args.clubName,args.clubPhoneNum, args.clubEmail, args.clubAddress,args.user)
        }
        composable<AboutScreen> {
            val args = it.toRoute<AboutScreen>()
            AboutScreenComp(dataViewModel, navController = navController,args.teamId, args.clubId, args.clubName,args.clubPhoneNum, args.clubEmail, args.clubAddress,args.user)
        }
        composable<TrainingScreen> {
            val args = it.toRoute<TrainingScreen>()
            TrainingScreenComp(dataViewModel, navController = navController, args.teamId, args.clubId, args.clubName,args.clubPhoneNum, args.clubEmail, args.clubAddress)
        }
    }
}

@Serializable
object LoginScreen

@Serializable
object SearchClubScreen

@Serializable
data class TeamsScreen(
    var teamId: Int,
    val user: Boolean,
    var clubId: Int,
    var clubName: String,
    var clubPhoneNum: String,
    var clubEmail: String,
    var clubAddress: String
)

@Serializable
data class TrainingScreen(
    var teamId: Int,
    var clubId: Int,
    var clubName: String,
    var clubPhoneNum: String,
    var clubEmail: String,
    var clubAddress: String
)

@Serializable
data class AboutScreen(
    var teamId: Int,
    val user: Boolean,
    var clubId: Int,
    var clubName: String,
    var clubPhoneNum: String,
    var clubEmail: String,
    var clubAddress: String
)

@Serializable
data class GamesResultsScreen(
    var teamId: Int,
    val user: Boolean,
    var clubId: Int,
    var clubName: String,
    var clubPhoneNum: String,
    var clubEmail: String,
    var clubAddress: String
)
