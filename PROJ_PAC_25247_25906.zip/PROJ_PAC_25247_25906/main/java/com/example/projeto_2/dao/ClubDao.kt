package com.example.projeto_2.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.projeto_2.entities.Club

@Dao
interface ClubDao {
    @Insert
    suspend fun insert(club: Club)

    @Insert
    suspend fun insertAll(clubs: List<Club>)

    @Query("SELECT * FROM clubs")
    fun getAllClubs(): List<Club>

    @Query("SELECT * FROM clubs WHERE id = :id")
    suspend fun getById(id: Int): Club?
}