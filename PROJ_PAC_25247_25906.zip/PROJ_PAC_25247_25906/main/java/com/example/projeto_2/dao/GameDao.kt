package com.example.projeto_2.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.projeto_2.entities.Game

@Dao
interface GameDao {
    @Query("DELETE FROM games")
    fun deleteAllGames()

    @Query("SELECT * FROM games")
    suspend fun getAllGames(): List<Game>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(games: List<Game>)

    @Query("SELECT * FROM games WHERE teamId = :teamId")
    suspend fun getGamesByTeamId(teamId: Int): List<Game>
}