package com.example.projeto_2.dao

interface ModalityDao {
}