package com.example.projeto_2.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.projeto_2.entities.Team

@Dao
interface TeamDao {
    @Query("SELECT * FROM teams")
    suspend fun getAllTeams(): List<Team>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(teams: List<Team>)

    @Query("SELECT * FROM teams WHERE clubId = :clubId")
    suspend fun getTeamByClubId(clubId: Int): List<Team>

    @Query("SELECT * FROM teams WHERE id = :id")
    suspend fun getTeamById(id: Int): Team

    @Query("DELETE FROM teams")
    fun deleteAllTeams()
}