package com.example.projeto_2.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.projeto_2.entities.Training

@Dao
interface TrainingDao {
    @Query("SELECT * FROM trainings")
    suspend fun getAllTraining(): List<Training>

    @Query("SELECT * FROM trainings WHERE teamId = :teamId")
    fun getByTeamId(teamId: Int): List<Training>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(trainings: List<Training>)

    @Query("DELETE FROM trainings")
    fun deleteAllTrainings()
}