package com.example.projeto_2.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.projeto_2.entities.User

@Dao
interface UserDao {
    @Insert
    suspend fun insert(user: User)

    @Insert
    suspend fun insertAll(users: List<User>)

    @Query("SELECT * FROM users WHERE username = :username AND password = :password")
    suspend fun authenticate(username: String, password: String): User?
}