package com.example.projeto_2.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "clubs")
data class Club(
    @PrimaryKey(autoGenerate = true) val id: Int,
    val name: String,
    val address: String,
    val telephoneNum: String,
    val email: String
)
