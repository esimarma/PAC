package com.example.projeto_2.entities

import androidx.room.Entity
import kotlinx.serialization.Serializable

@Entity(primaryKeys = ["clubId", "modalityId"], tableName = "club_modality_cross_ref")
data class ClubModalityCrossRef(
    val clubId: Int,
    val modalityId: Int
)