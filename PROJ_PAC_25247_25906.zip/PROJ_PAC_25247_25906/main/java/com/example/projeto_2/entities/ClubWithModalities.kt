package com.example.projeto_2.entities

import androidx.room.Embedded
import androidx.room.Junction
import androidx.room.Relation

data class ClubWithModalities(
    @Embedded val club: Club,
    @Relation(
        parentColumn = "id",
        entityColumn = "id",
        associateBy = Junction(ClubModalityCrossRef::class)
    )
    val modalities: List<Modality>
)