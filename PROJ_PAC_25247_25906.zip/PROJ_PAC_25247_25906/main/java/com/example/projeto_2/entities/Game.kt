package com.example.projeto_2.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Entity(tableName = "games")
data class Game(
    @PrimaryKey(autoGenerate = true) val id: Int,
    val homeScore: Int,
    val awayScore: Int,
    val awayLogo: Int,
    val teamId: Int
)