package com.example.projeto_2.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Entity(tableName = "modalities")
data class Modality(
    @PrimaryKey(autoGenerate = true) val id: Int,
    val name: String
)