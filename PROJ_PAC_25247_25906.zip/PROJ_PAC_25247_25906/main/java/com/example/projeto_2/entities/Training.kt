package com.example.projeto_2.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Entity(tableName = "trainings")
data class Training(
    @PrimaryKey(autoGenerate = true) val id: Int,
    val dayOfTheWeek: String,
    val time: String,
    val local: String,
    val teamId: Int
)