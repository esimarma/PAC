package com.example.projeto_2.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import com.example.projeto_2.R
import com.example.projeto_2.viewModel.DataViewModel

@Composable
fun AboutScreenComp(dataViewModel: DataViewModel, navController: NavHostController, teamId:Int, clubId: Int, clubName: String, clubPhoneNum: String, clubEmail: String, clubAdress: String, user: Boolean) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF133C49))
    ) {
        if(user){
            HeaderUser(navController, clubName)
        }
        else{
            HeaderGest(navController, clubName)
        }
        Spacer(modifier = Modifier.height(40.dp))
        About(clubName, clubPhoneNum, clubEmail, clubAdress)
        Spacer(modifier = Modifier.weight(1f))
        BottomNavigationBar(navController, teamId, clubId, clubName, clubPhoneNum, clubEmail, clubAdress, "sobre", user)
    }
}

@Composable
fun About(clubName: String, clubPhoneNum: String, clubEmail: String, clubAdress: String) {
    var aboutClub = listOf("+351 293 123 432","geral@clube.com","Avenida 25 de abril, nº13")
    var modalities = listOf("Futebol","Andebol","Basquetebol")

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        Card(
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(Color(0xFF5FC3DD)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
        ) {
            Row(modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .background(Color.White, shape = RoundedCornerShape(8.dp)),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(text = "Sobre o Clube", fontSize = 24.sp, color = Color.Black, textAlign = TextAlign.Center)
                }
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(
                    verticalArrangement = Arrangement.Center,
                    //modifier = Modifier.weight(1f)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.icone_telemovel),
                        contentDescription = "Telefone",
                        modifier = Modifier.size(40.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .padding(8.dp)
                ) {
                    Text(text = clubPhoneNum, fontSize = 24.sp, color = Color.White, textAlign = TextAlign.Center)
                }
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(
                    verticalArrangement = Arrangement.Center,
                    //modifier = Modifier.weight(1f)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.icon_email),
                        contentDescription = "email",
                        modifier = Modifier.size(40.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .padding(8.dp)
                ) {
                    Text(text = clubEmail, fontSize = 24.sp, color = Color.White, textAlign = TextAlign.Center)
                }
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(
                    verticalArrangement = Arrangement.Center,
                    //modifier = Modifier.weight(1f)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.icon_home),
                        contentDescription = "morada",
                        modifier = Modifier.size(40.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .padding(8.dp)
                ) {
                    Text(text = clubAdress, fontSize = 24.sp, color = Color.White, textAlign = TextAlign.Center)
                }
            }

            Row(modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .background(Color.White, shape = RoundedCornerShape(8.dp)),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(text = "Modalidades", fontSize = 24.sp, color = Color.Black, textAlign = TextAlign.Center)
                }
            }

            LazyColumn {
                items(modalities.size) { index ->
                    Modalities(modalities[index])
                }
            }
        }
    }
}

@Composable
fun Modalities(modality: String){
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Box(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 14.dp)
        ) {
            Text(text = "- $modality", fontSize = 24.sp, color = Color.White, textAlign = TextAlign.Center)
        }
    }
}

@Preview(showBackground = true)
@Composable
fun AboutScreenPrev() {
    //AboutScreenComp(navController = rememberNavController(), 1, "teste","teste","teste", "teste", true)
}