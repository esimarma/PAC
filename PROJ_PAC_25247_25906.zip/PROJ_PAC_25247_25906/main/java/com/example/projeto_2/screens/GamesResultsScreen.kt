package com.example.projeto_2.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.example.projeto_2.R
import com.example.projeto_2.entities.Game
import com.example.projeto_2.viewModel.DataViewModel

@Composable
fun GamesResultsScreenComp(dataViewModel: DataViewModel,navController: NavHostController, teamId:Int, clubId: Int, clubName: String, clubPhoneNum: String, clubEmail: String, clubAddress: String, user: Boolean) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF133C49))
    ) {
        if(user){
            HeaderUser(navController, clubName)
        }
        else{
            HeaderGest(navController, clubName)
        }
        Spacer(modifier = Modifier.height(25.dp))
        GameList(dataViewModel, clubId, clubName)
        Spacer(modifier = Modifier.weight(1f))
        BottomNavigationBar(navController, teamId, clubId ,clubName, clubPhoneNum, clubEmail, clubAddress, "jogos", user)
    }
}

@Composable
fun GameList(dataViewModel: DataViewModel, clubId: Int, clubName: String) {
    var games by remember { mutableStateOf(emptyList<Game>()) }

    // Use LaunchedEffect para carregar os jogos de forma assíncrona
    LaunchedEffect(clubId) {
        games = dataViewModel.getGamesByClubId(clubId)
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        Row(modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier.weight(1f)
            ) {
                Text(text = "Resultados dos Jogos:", fontSize = 24.sp, color = Color.White, textAlign = TextAlign.Center)
            }
        }

        games.forEach { game ->
            var teamName by remember { mutableStateOf("") }
            LaunchedEffect(game.teamId) {
                val team = dataViewModel.getTeamById(game.teamId)
                team.let {
                    teamName = it.name
                }
            }
            GameItem(clubName, teamName, game.homeScore, game.awayScore, game.awayLogo)
        }
    }
}

@Composable
fun GameItem(club: String,category: String, homeScore: Int, awayScore: Int, awayLogo: Int) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(
            Color(0xFF5FC3DD),
        ),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Row(modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
            .background(Color.White, shape = RoundedCornerShape(8.dp)),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.weight(1f)
            ) {
                Text(text = category, fontSize = 20.sp, color = Color.Black, textAlign = TextAlign.Center)
            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.weight(1f)
            ) {
                if(club == "Benfica"){
                    Image(
                        painter = painterResource(id = R.drawable.benfica_logo),
                        contentDescription = "Benfica Logo",
                        modifier = Modifier.size(40.dp)
                    )
                }
                else if(club == "Porto"){
                    Image(
                        painter = painterResource(id = R.drawable.porto_logo),
                        contentDescription = "porto Logo",
                        modifier = Modifier.size(40.dp)
                    )
                }
                else if(club == "Sporting"){
                    Image(
                        painter = painterResource(id = R.drawable.sporting_logo),
                        contentDescription = "sporting Logo",
                        modifier = Modifier.size(40.dp)
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
            }
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.weight(1f)
            ) {
                Text(text = "$homeScore - $awayScore", fontSize = 18.sp, color = Color.White, textAlign = TextAlign.Center)
            }
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.weight(1f)
            ) {
                Image(
                    painter = painterResource(id = awayLogo),
                    contentDescription = "Away Team Logo",
                    modifier = Modifier.size(40.dp)
                )
                Spacer(modifier = Modifier.height(4.dp))
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewGamesResultsScreenComp() {
   // GamesResultsScreenComp(dataViewModel,navController = rememberNavController(),0, "", "", "", "", true)
}