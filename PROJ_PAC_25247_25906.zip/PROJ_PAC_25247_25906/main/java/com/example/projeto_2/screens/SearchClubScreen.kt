package com.example.projeto_2.screens


import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import com.example.projeto_2.GamesResultsScreen
import com.example.projeto_2.LoginScreen
import com.example.projeto_2.R
import com.example.projeto_2.viewModel.DataViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchClubScreenComp(navController: NavHostController, viewModel: DataViewModel) {
    val clubs by viewModel.clubList.collectAsState(initial = emptyList())
    var expanded by remember { mutableStateOf(false) }
    var selectedIdClub by remember { mutableStateOf(clubs.firstOrNull()?.id ?: 0) }
    var selectedNameClub by remember { mutableStateOf(clubs.firstOrNull()?.name ?: "") }
    var selectedPhoneNumClub by remember { mutableStateOf(clubs.firstOrNull()?.telephoneNum ?: "") }
    var selectedEmailClub by remember { mutableStateOf(clubs.firstOrNull()?.email ?: "") }
    var selectedAdressClub by remember { mutableStateOf(clubs.firstOrNull()?.address ?: "") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF133C49))
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painter = painterResource(id = R.drawable.logo_300),
            contentDescription = "Logo",
            modifier = Modifier.size(300.dp)
        )

        Spacer(modifier = Modifier.height(30.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp)
        ) {
            ExposedDropdownMenuBox(
                expanded = expanded,
                onExpandedChange = {
                    expanded = !expanded
                }
            ) {
                TextField(
                    value = selectedNameClub,
                    onValueChange = {},
                    readOnly = true,
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                    modifier = Modifier.menuAnchor()
                )

                ExposedDropdownMenu(
                    expanded = expanded,
                    onDismissRequest = { expanded = false }
                ) {
                    clubs.forEach { club ->
                        DropdownMenuItem(
                            text = { Text(text = club.name) },
                            onClick = {
                                selectedIdClub = club.id
                                selectedNameClub = club.name
                                selectedPhoneNumClub = club.telephoneNum
                                selectedEmailClub = club.email
                                selectedAdressClub = club.address
                                expanded = false
                            }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(
            modifier = Modifier.padding(horizontal = 32.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Button(
                onClick = { navController.navigate(LoginScreen) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF5FC3DD)),
                modifier = Modifier.weight(1f).padding(end = 8.dp)
            ) {
                Text("Voltar", color = Color.White)
            }

            Button(
                onClick = { navController.navigate(GamesResultsScreen(0, false,selectedIdClub, selectedNameClub, selectedPhoneNumClub, selectedEmailClub, selectedAdressClub)) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF5FC3DD)),
                modifier = Modifier.weight(1f).padding(start = 8.dp)
            ) {
                Text("Ok", color = Color.White)
            }
        }
    }
}


@Preview(showBackground = true)
@Composable
private fun HomeScreenPrev() {
    SearchClubScreenComp(navController = rememberNavController(), viewModel = viewModel())
}