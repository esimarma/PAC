package com.example.projeto_2.screens


import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.example.projeto_2.AboutScreen
import com.example.projeto_2.GamesResultsScreen
import com.example.projeto_2.LoginScreen
import com.example.projeto_2.R
import com.example.projeto_2.TeamsScreen
import com.example.projeto_2.TrainingScreen

@Composable
fun HeaderUser(navController: NavHostController, club: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF5FC3DD))
            .padding(vertical = 20.dp)
    ) {
        Icon(
            painter = painterResource(id = R.drawable.icone_voltar),
            contentDescription = "X",
            modifier = Modifier
                .size(40.dp)
                .align(Alignment.CenterStart)
                .padding(start = 8.dp)
                .clickable {navController.navigate(LoginScreen)},
            tint = Color.White
        )
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.align(Alignment.Center)
        ) {
            if(club == "Benfica"){
                Image(
                    painter = painterResource(id = R.drawable.benfica_logo),
                    contentDescription = "Benfica Logo",
                    modifier = Modifier.size(60.dp)
                )
            }
            else if(club == "Porto"){
                Image(
                    painter = painterResource(id = R.drawable.porto_logo),
                    contentDescription = "porto Logo",
                    modifier = Modifier.size(60.dp)
                )
            }
            else if(club == "Sporting"){
                Image(
                    painter = painterResource(id = R.drawable.sporting_logo),
                    contentDescription = "sporting Logo",
                    modifier = Modifier.size(60.dp)
                )
            }

        }
        Icon(
            painter = painterResource(id = R.drawable.icon_user),
            contentDescription = "Profile",
            modifier = Modifier
                .size(40.dp)
                .align(Alignment.CenterEnd)
                .padding(end = 8.dp)
                .clickable {},
            tint = Color.White
        )
    }
}

@Composable
fun HeaderGest(navController: NavHostController, club: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF5FC3DD))
            .padding(vertical = 16.dp)
    ) {
        Icon(
            painter = painterResource(id = R.drawable.icone_voltar),
            contentDescription = "X",
            modifier = Modifier
                .size(40.dp)
                .align(Alignment.CenterStart)
                .padding(start = 8.dp)
                .clickable {navController.navigate(LoginScreen)},
            tint = Color.White
        )
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.align(Alignment.Center)
        ) {
            if(club == "Benfica"){
                Image(
                    painter = painterResource(id = R.drawable.benfica_logo),
                    contentDescription = "Benfica Logo",
                    modifier = Modifier.size(60.dp)
                )
            }
            else if(club == "Porto"){
                Image(
                    painter = painterResource(id = R.drawable.porto_logo),
                    contentDescription = "porto Logo",
                    modifier = Modifier.size(60.dp)
                )
            }
            else if(club == "Sporting"){
                Image(
                    painter = painterResource(id = R.drawable.sporting_logo),
                    contentDescription = "sporting Logo",
                    modifier = Modifier.size(60.dp)
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = club,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
}

@Composable
fun BottomNavigationBar(navController: NavHostController, teamId: Int, clubId: Int, clubName: String, clubPhoneNum: String, clubEmail: String, clubAddress: String, selectedB: String, user: Boolean) {
    // Create a state to keep track of the currently selected button
    var selectedButton by remember { mutableStateOf<String?>(selectedB) }


    // Define a composable for a single button to avoid code duplication
    @Composable
    fun CustomButton(
        buttonName: String,
        onClick: () -> Unit,
        iconId: Int,
        text: String,
        modifier: Modifier = Modifier
    ) {
        val isSelected = selectedButton == buttonName
        val height by animateDpAsState(if (isSelected) 100.dp else 90.dp) // Animate height change

        Button(
            onClick = {
                //onButtonClick(buttonName)
                onClick() },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00BCD4)),
            shape = RectangleShape,
            modifier = modifier
                .height(height)
                .border(
                    width = if (isSelected) 2.dp else 0.dp,
                    color = if (isSelected) Color(0xFF133C49) else Color.Transparent,
                    shape = RectangleShape
                )
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(painter = painterResource(id = iconId),
                    contentDescription = text,
                    tint = Color.White,
                    modifier = Modifier.size(50.dp))
                Text(text = text, color = Color.White)
            }
        }
    }

    Row(
        modifier = Modifier
            .fillMaxWidth(),
        // .background(Color(0xFF00BCD4)),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.Bottom
    ) {
        CustomButton(
            buttonName = "equipas",
            onClick = { /*navController.navigate(TeamsScreen(teamId,user,clubId, clubName, clubPhoneNum, clubEmail, clubAddress))*/},
            iconId = R.drawable.icone_equipas,
            text = "Equipas",
            modifier = Modifier.weight(1f)
        )
        CustomButton(
            buttonName = "jogos",
            onClick = { navController.navigate(GamesResultsScreen(teamId,user,clubId, clubName, clubPhoneNum, clubEmail, clubAddress)) },
            iconId = R.drawable.iconejogos,
            text = "Jogos",
            modifier = Modifier.weight(1f)
        )
        if(user){
            CustomButton(
                buttonName = "treinos",
                onClick = { navController.navigate(TrainingScreen(teamId, clubId, clubName, clubPhoneNum, clubEmail, clubAddress)) },
                iconId = R.drawable.icone_treinos,
                text = "Treinos",
                modifier = Modifier.weight(1f)
            )
        }
        CustomButton(
            buttonName = "sobre",
            onClick = { navController.navigate(AboutScreen(teamId, user, clubId, clubName,clubPhoneNum,clubEmail,clubAddress)) },
            iconId = R.drawable.icone_sobre,
            text = "Sobre",
            modifier = Modifier.weight(1f)
        )
    }
}