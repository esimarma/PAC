package com.example.projeto_2.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.example.projeto_2.R
import com.example.projeto_2.viewModel.DataViewModel

@Composable
fun TeamsScreenComp(dataViewModel: DataViewModel, navController: NavHostController, teamId:Int, clubId: Int, clubName: String, clubPhoneNum: String, clubEmail: String, clubAdress: String, user: Boolean) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF133C49))
    ) {
        HeaderUser(navController, clubName)
        Spacer(modifier = Modifier.height(30.dp))
        TeamsScreen()
        Spacer(modifier = Modifier.weight(1f))
        BottomNavigationBar(navController, teamId, clubId ,clubName,clubPhoneNum,clubEmail,clubAdress,"equipas", user)
    }
}

@Composable
fun TeamsScreen() {
    Column(
        modifier = Modifier
            .padding(16.dp)
            .fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier.weight(1f)
            ) {
                Text(text = "Equipas:", fontSize = 24.sp, color = Color.White, textAlign = TextAlign.Center)
            }
        }
        TeamItem(teamName = "Equipa 1", imageRes = R.drawable.porto_logo)
        TeamItem(teamName = "Equipa 2", imageRes = R.drawable.porto_logo)
    }
}

@Composable
fun TeamItem(teamName: String, imageRes: Int) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        Image(
            painter = painterResource(id = imageRes),
            contentDescription = "Foto da $teamName",
            modifier = Modifier
                .fillMaxWidth()
                .height(150.dp),
            contentScale = ContentScale.Crop
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = teamName,
        )
    }
}

@Preview(showBackground = true)
@Composable
fun TeamsScreenPreview() {
    //TeamsScreen()
}