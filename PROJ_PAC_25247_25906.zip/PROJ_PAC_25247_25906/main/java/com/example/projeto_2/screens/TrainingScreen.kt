package com.example.projeto_2.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import com.example.projeto_2.entities.Game
import com.example.projeto_2.entities.Training
import com.example.projeto_2.viewModel.DataViewModel

@Composable
fun TrainingScreenComp(dataViewModel: DataViewModel, navController: NavHostController, teamId:Int, clubId: Int, clubName: String, clubPhoneNum: String, clubEmail: String, clubAdress: String) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF133C49))
    ) {
        HeaderUser(navController, clubName)
        Spacer(modifier = Modifier.height(30.dp))
        Training(dataViewModel, teamId)
        Spacer(modifier = Modifier.weight(1f))
        BottomNavigationBar(navController, teamId, clubId ,clubName,clubPhoneNum,clubEmail,clubAdress,"treinos", true)
    }
}

@Composable
fun Training(dataViewModel: DataViewModel, teamId:Int) {
   /* var training = listOf(
        listOf("Segunda-feira","17:00","Estádio B"),
        listOf("Quarta-feira","9:00","Campo A"),
        listOf("Sexta-feira","17:30","Campo C")
    )*/
    var training by remember { mutableStateOf(emptyList<Training>()) }

    // Use LaunchedEffect para carregar os jogos de forma assíncrona
    LaunchedEffect(teamId) {
        training = dataViewModel.getTrainingsByTeamId(teamId)
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp)
    ) {
        Row(modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Box(
                modifier = Modifier.weight(1f)
            ) {
                Text(text = "Os Seus Treinos:", fontSize = 24.sp, color = Color.White, textAlign = TextAlign.Center)
            }
        }

        Card(
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(Color(0xFF5FC3DD)),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
        ) {
            LazyColumn {
                items(training.size) { index ->
                    Row(modifier = Modifier
                        .fillMaxWidth()
                        .padding(8.dp)
                        .background(Color.White, shape = RoundedCornerShape(8.dp)),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(text = training[index].dayOfTheWeek, fontSize = 24.sp, color = Color.Black, textAlign = TextAlign.Center)
                        }
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 14.dp)
                        ) {
                            Text(text = "Horário:" + training[index].time, fontSize = 20.sp, color = Color.Black, textAlign = TextAlign.Center)
                        }
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 14.dp)
                        ) {
                            Text(text = "Local:" + training[index].local, fontSize = 20.sp, color = Color.Black, textAlign = TextAlign.Center)
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))

                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun TrainingScreenPrev() {
   // TrainingScreenComp(navController = rememberNavController(),1,"","","","")
}