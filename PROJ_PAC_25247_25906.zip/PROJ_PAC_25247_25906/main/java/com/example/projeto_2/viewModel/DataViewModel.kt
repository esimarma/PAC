package com.example.projeto_2.viewModel

import android.app.Application
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.projeto_2.AppDatabase
import com.example.projeto_2.R
import com.example.projeto_2.entities.Club
import com.example.projeto_2.entities.Game
import com.example.projeto_2.entities.Team
import com.example.projeto_2.entities.Training
import com.example.projeto_2.entities.User
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class DataViewModel(application: Application) : AndroidViewModel(application) {
    private val userDao = AppDatabase.getDatabase(application).userDao()
    private val clubDao = AppDatabase.getDatabase(application).clubDao()
    private val teamDao = AppDatabase.getDatabase(application).teamDao()
    private val gameDao = AppDatabase.getDatabase(application).gameDao()
    private val trainingDao = AppDatabase.getDatabase(application).trainingDao()

    fun authenticate(username: String, password: String, callback: (User?, Club?) -> Unit) {
        viewModelScope.launch {
            val user = withContext(Dispatchers.IO) {
                userDao.authenticate(username, password)
            }
            val club = user?.clubId?.let { clubId ->
                withContext(Dispatchers.IO) {
                    clubDao.getById(clubId)
                }
            }
            callback(user, club)
        }
    }

    private val _clubList = MutableStateFlow<List<Club>>(emptyList())
    val clubList: StateFlow<List<Club>> = _clubList

    init {
        viewModelScope.launch(Dispatchers.IO) {
            initializeData()
            val clubs = clubDao.getAllClubs()
            _clubList.value = clubs
        }
    }

    private suspend fun initializeData() {
        // Verifique se já existem dados na tabela antes de inserir
        if (clubDao.getAllClubs().isEmpty()) {
            val clubs = listOf(
                Club(1, "Sporting","Rua do sporting", "928371623", "teste@sporting.pt"),
                Club(2, "Benfica","Rua do benfica", "928371623", "teste@benfica.pt"),
                Club(3, "Porto","Rua do porto", "928371623", "teste@porto.pt")
            )
            clubDao.insertAll(clubs)
        }
        // Verifique se já existem dados na tabela antes de inserir
        teamDao.deleteAllTeams()
        if (teamDao.getAllTeams().isEmpty()) {
            val teams = listOf(
                Team(1, "Juniores", 1),
                Team(2, "Infantis", 1),
                Team(3, "Iniciados", 1),
                Team(4, "Juvenis", 1),
                Team(5, "Juniores", 2),
                Team(6, "Infantis", 2),
                Team(7, "Iniciados", 2),
                Team(8, "Juvenis", 2),
                Team(9, "Juniores", 3),
                Team(10, "Infantis", 3),
                Team(11, "Iniciados", 3),
                Team(12, "Juvenis", 3)
            )
            teamDao.insertAll(teams)
        }
        gameDao.deleteAllGames()
        if (gameDao.getAllGames().isEmpty()) {
            val games = listOf(
                Game(0, 2, 1, R.drawable.portugal_logo, 1),
                Game(0, 3, 0, R.drawable.benfica_logo, 2),
                Game(0, 1, 1, R.drawable.porto_logo, 3),
                Game(0, 3, 0, R.drawable.benfica_logo, 4),
                Game(0, 3, 0, R.drawable.porto_logo, 3),

                Game(0, 2, 1, R.drawable.sporting_logo, 5),
                Game(0, 3, 0, R.drawable.porto_logo, 6),
                Game(0, 1, 1, R.drawable.sporting_logo, 7),
                Game(0, 3, 0, R.drawable.portugal_logo, 8),
                Game(0, 3, 0, R.drawable.porto_logo, 5),

                Game(0, 2, 1, R.drawable.benfica_logo, 9),
                Game(0, 3, 0, R.drawable.portugal_logo, 10),
                Game(0, 1, 1, R.drawable.benfica_logo, 11),
                Game(0, 3, 0, R.drawable.sporting_logo, 12),
                Game(0, 3, 0, R.drawable.sporting_logo, 9),
            )
            gameDao.insertAll(games)
        }

        trainingDao.deleteAllTrainings()
        if (trainingDao.getAllTraining().isEmpty()) {
            val training = listOf(
                Training(0, "Segunda-feira","17:30", "Campo B", 1),
                Training(0, "Quarta-feira","9:00", "Campo A", 1),
                Training(0, "Sexta-feira","17:00", "Campo C", 1),
                Training(0, "Segunda-feira","17:30", "Campo B", 2),
                Training(0, "Quarta-feira","9:00", "Campo A", 2),
                Training(0, "Sexta-feira","17:00", "Campo C", 2),
                Training(0, "Segunda-feira","17:30", "Campo B", 3),
                Training(0, "Quarta-feira","9:00", "Campo A", 3),
                Training(0, "Sexta-feira","17:00", "Campo C", 3),
            )
            trainingDao.insertAll(training)
        }
    }

    suspend fun getGamesByClubId(clubId: Int): List<Game> = withContext(Dispatchers.IO) {
        val gameList = mutableListOf<Game>()

        // Use coroutineScope para garantir que todas as corrotinas sejam concluídas antes de retornar
        coroutineScope {
            val teams = teamDao.getTeamByClubId(clubId)

            teams.forEach { team ->
                val games = gameDao.getGamesByTeamId(team.id)
                gameList.addAll(games)
            }
        }

        return@withContext gameList
    }

    suspend fun getTeamById(teamId: Int): Team = withContext(Dispatchers.IO) {
        return@withContext teamDao.getTeamById(teamId)
    }

    suspend fun getTrainingsByTeamId(teamId: Int): List<Training> = withContext(Dispatchers.IO) {
        return@withContext trainingDao.getByTeamId(teamId)
    }

}