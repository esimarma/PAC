window.addEventListener('DOMContentLoaded', event => {
    // Activate Bootstrap scrollspy on the main nav element
    const mainNav = document.body.querySelector('#mainNav');
    if (mainNav) {
        new bootstrap.ScrollSpy(document.body, {
            target: '#mainNav',
            rootMargin: '0px 0px -40%',
        });
    };

    // Collapse responsive navbar when toggler is visible
    const navbarToggler = document.body.querySelector('.navbar-toggler');
    const responsiveNavItems = [].slice.call(
        document.querySelectorAll('#navbarResponsive .nav-link')
    );
    responsiveNavItems.map(function (responsiveNavItem) {
        responsiveNavItem.addEventListener('click', () => {
            if (window.getComputedStyle(navbarToggler).display !== 'none') {
                navbarToggler.click();
            }
        });
    });

    jsonCall();
});

let jsonLang = "json/pt.json";

function changeLang(){
    //Alterar de pt para en
    if(jsonLang == "json/pt.json"){
        jsonLang = "json/en.json";
        document.getElementById("flag").src = "assets/flags/pt.png"
    }
    else if(jsonLang == "json/en.json"){
        jsonLang = "json/pt.json";
        document.getElementById("flag").src = "assets/flags/en.png"
    }

    jsonCall();
}

function jsonCall(){
    //Chamada do json e mudar a conteudo dos elementos.
    fetch(jsonLang).then((response) => {
        response.json().then((data) => {
            document.getElementById("aboutNav").innerHTML = data.about;
            document.getElementById("funcNav").innerHTML = data.func;
            document.getElementById("contactNav").innerHTML = data.contact;
            document.getElementById("aboutTitle").innerHTML = data.aboutTitle;
            document.getElementById("aboutText").innerHTML = data.aboutText;
            document.getElementById("install").innerHTML = data.install;
            document.getElementById("funcTitle").innerHTML = data.funcTitle;
            document.getElementById("func1").innerHTML = data.func1;
            document.getElementById("func2").innerHTML = data.func2;
            document.getElementById("func3").innerHTML = data.func3;
            document.getElementById("func4").innerHTML = data.func4;
            document.getElementById("func5").innerHTML = data.func5;
            document.getElementById("func6").innerHTML = data.func6;
            document.getElementById("func7").innerHTML = data.func7;
            document.getElementById("contactText").innerHTML = data.contactText;
        })
    })
}



